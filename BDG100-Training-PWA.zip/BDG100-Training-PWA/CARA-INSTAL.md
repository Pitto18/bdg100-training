BDG100 Training PWA

PWA ini perlu di-host di alamat HTTPS agar fitur install dan service worker aktif.

Langkah umum:
1. Upload seluruh isi folder ini ke hosting statis HTTPS (misalnya GitHub Pages atau layanan static hosting).
2. Buka alamatnya di Chrome Android tablet.
3. Pilih menu browser > Install app / Add to Home screen.
4. Di iPhone: buka alamat di Safari > tombol Share > Add to Home Screen.

Data latihan tersimpan secara lokal di browser. Gunakan tombol Ekspor data untuk membuat backup.
